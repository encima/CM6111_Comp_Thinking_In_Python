
# interpreted

#integer
i = 10

#string
name = 'Justin'
#string
# variable = literal
name2 = 'Garin'
print(name2)
name2 = 10
print(name2)

def email_student():
    #send email
    print('Thanks for letting me know')
    print('person')
    x = 10
    x = x + 5
#array
            #literals
names = ['Garin', 'Justin', 'Chris', 'Ian', 'Matthew', 'Carl']
for i in range(0, len(names)):
    email_student()
    print names[i]
print(names[2])
names = []

names.append('Trevor')
print(len(names))


# system method
print('hello ' + str(i))
print(name2)

email_student()
