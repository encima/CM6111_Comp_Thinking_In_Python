import config

print(config.city_name)
