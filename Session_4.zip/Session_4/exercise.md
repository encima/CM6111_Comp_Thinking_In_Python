## Session 4 Exercises

1. Sort the list and print the sorted list below, along with the code to sort it:

`unsorted = ['billy', 'april', 'june', 'xander', 'dylan']`

2. What is the index of the 'april' value in the sorted list?

3. Print out the length of the list.

4. How could I access the last element in the list?

5. How is a list different from an array in other languages? (max. 200 words) Quote your sources!

6. Use a while loop to add numbers to the list until the user enters `quit`

7. Loop through the list and print out the index of each even number

8. Print out the mean of the list elements
